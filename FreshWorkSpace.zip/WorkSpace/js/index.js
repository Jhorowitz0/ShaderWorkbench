(function(global){
  function main(){
  }
})